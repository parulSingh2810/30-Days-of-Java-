package com.accenture.lkm.junit;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ThreeTest {

	@Test
	
	void test() {
		Assertions.fail("Not yet implemented");
	}

}
